
# Starbucks Nutrition Finder

## Project Description
A Machine Learning application that predicts
whether a Starbucks drink has Low, Medium,
or High calories.

## Technologies Used
- Python
- Pandas
- Scikit-learn
- Decision Tree Classifier
- Streamlit

## Model Accuracy
Validation Accuracy: 91%

## How to Run
1. Install requirements:
   pip install -r requirements.txt

2. Start the application:
   streamlit run app.py

## Project Goal
To help users understand the calorie category
of Starbucks beverages.
